function [final_result,label,history,iter,H,H_hat] = main(B_hat,Y,nv,nc,anchor_rate,p,lambda,IterMax)
% XΪ���룬nCΪ�����,MΪê����
N = size(B_hat{1},1);
M = fix(N*anchor_rate);
betaf = ones(nv, 1); % ������Ȩ��

%% initial
directions = [1,2];                         % �ݶ����������鼯��
n = length(directions);
for i = 1:N
    II(i,mod(i, nc)+1) = 1;
end
for v = 1:nv
    % ��Ҫ���³�ʼ��
    H_hat{v} = II; %n*c
    K_hat{v} = zeros(M,nc);
    J1_hat{v} = zeros(N,nc);
    J2_hat{v} = zeros(N,nc);
    A_hat{v} = zeros(N,nc);
    Y1{v} = zeros(N,nc);
    Y2{v} = zeros(N,nc);
    Y3_hat{v} = zeros(N,nc);
    Y3{v} = zeros(N,nc);
    A{v}= zeros(N,nc);
end
mu = 1e-3;
max_mu = 1e9;
coe = 1.1;
final_result = zeros(1,7);
sX1 = [N, nc, nv];
epson = 1e-3;
iter = 0;
Isconverg = 0;
time_start = clock;
dim = [N,nc,nv];

%% FFT setting
T = zeros(dim);
for i = 1:n
    Eny = diff_element(dim,directions(i));
    T   = T + Eny; 
end
% �õ�ȫ�������ת�á�ȫ������ӵ������ʽ,Ϊ�����������ݶ���������

while(Isconverg == 0) 
    %% update K_hat{v}
    for v = 1:nv
        [a1, a2, a3] = mySVD(full(B_hat{v}'*H_hat{v}));
        K_hat{v} = a1*pinv(full(a2))*abs(a2)*a3';
    end 
    
    
    
   %% update H_hat{v} n*c*V
    for v = 1:nv
        C_hat{v} = B_hat{v}*K_hat{v}./mu + (A_hat{v} - Y3_hat{v}./mu);
    end
    C_t=frequency2time(C_hat);
    %C_t=C_hat;
    for v = 1:nv
        C=C_t{v};
        for j = 1:N
            QQQ = C(j,:);
            H{v}(j,:) = EProjSimplex_new(QQQ,1);
        end
    end
    %H = frequency2time(H_hat);
    H_hat = time2frequency(H);
    clear C QQQ C_t C_hat
    
    
    %% update J1
    for v =1:nv
        HY1{v} = porder_diff(A{v},1) + Y1{v}./mu;
    end
    UY1_tensor = cat(3,HY1{:,:});
    [myj, ~] = wshrinkObj_weight_lp(UY1_tensor(:), lambda*betaf./mu,sX1, 0,3,p);
    J1_tensor = reshape(myj, sX1);
    for k=1:nv
        J1{k} = J1_tensor(:,:,k);
    end
    J1_hat=time2frequency(J1);
    clear J1_tensor
        %% update J2
    for v =1:nv
        HY2{v} = porder_diff(A{v},2) + Y2{v}./mu;
    end
    UY2_tensor = cat(3,HY2{:,:});
    [myj, ~] = wshrinkObj_weight_lp(UY2_tensor(:), lambda*betaf./mu,sX1, 0,3,p);
    J2_tensor = reshape(myj, sX1);
    for k=1:nv
        J2{k} = J2_tensor(:,:,k);
    end
    J2_hat=time2frequency(J2);
    clear J2_tensor
    
    

   
    %% ��������A_tensor
    J1_tensor = cat(3, J1{:,:});
    J2_tensor = cat(3, J2{:,:});
    Y1_tensor = cat(3, Y1{:,:});
    Y2_tensor = cat(3, Y2{:,:});
    Y3_tensor = cat(3, Y3{:,:});
    HA = porder_diff_T(mu*J1_tensor-Y1_tensor,1) + porder_diff_T(mu*J2_tensor-Y2_tensor,2); 
    H_tensor = cat(3,H{:,:});
    A_tensor = real( ifftn( fftn( mu*H_tensor+Y3_tensor+HA)./(mu*(1+T)) ) );
    for v = 1:nv
        A{v} = A_tensor(:, :, v);
    end
    A_hat = time2frequency(A);

    %% update Y1{v}
    for v = 1:nv
        Y1{v} = Y1{v}+mu*(porder_diff(A{v},1)-J1{v});
    end
    
    %% update Y2{v}
    for v = 1:nv
        Y2{v} = Y2{v}+mu*(porder_diff(A{v},2)-J2{v});
    end
    
    %% update Y3{v}
    for v = 1:nv
        Y3{v} = Y3{v}+mu*(H{v}-A{v});
    end
    Y3_hat = time2frequency(Y3);

    %% update mu
    mu = min(mu*coe, max_mu);

      
    %% Clustering result
    H_sum = zeros(N,nc);
    for v=1:nv
        H_sum = H_sum + H{v};
    end
    [~, label] = max(H_sum, [], 2);
    result = ClusteringMeasure1(Y,label);
    if (sum(result) - sum(final_result))>0
        final_result = result;
    end

    
    %% converge
    Isconverg = 1;                      %�����㷨�Ѿ�����
    for v = 1:nv                     %ͨ�� for ѭ�����������е�����Ԫ��
        if (norm(H{v} - A{v},inf)>epson || norm(porder_diff(A{v},2)-J2{v},inf)>epson || norm(porder_diff(A{v},1)-J1{v},inf)>epson)
            history.norm_H_A(iter+1) = norm(H{v} - A{v},inf);
            history.normJ1(iter+1)= norm(porder_diff(A{v},1)-J1{v},inf);
            history.normJ2(iter+1)= norm(porder_diff(A{v},2)-J2{v},inf);
            history.ACC(iter+1)=final_result(1);
            history.NMI(iter+1)=final_result(2);
            Isconverg = 0;%�����㷨��δ����
        end
    end
    %%
    if (iter > IterMax)
        Isconverg  = 1;
    end
    
    
%    fprintf('iter:%d H-J=%.6f\n',iter,norm(H{v} - J{v},inf))
    iter = iter + 1;

end
time_end = clock;
% fprintf('Time_all:%f s\n',etime(time_end,time_start))
% fprintf('Time_average:%f s\n',etime(time_end,time_start)/iter)
fprintf('Final_iter:%d\n',iter)
    
    
end

