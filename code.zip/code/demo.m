clear all;
close all
clc;
addpath([pwd, '/funs']);
addpath([pwd, '/datasets']);
addpath('D:/code/datasets')

%% load data
dataname='HW1256';
load(strcat(dataname,'.mat'));
% Y=gt;
nv = length(X);
nc = length(unique(Y));
num_N = size(X{1},1); 
%% Data pre-processing A
disp('------Data preprocessing------');
tic
for v = 1:nv
    a = max(X{v}(:));
    X{v} = double(X{v}./a);
end
toc


%% setting
anchor_rate = [0.1];
p = [0.9];
lambda1= [5];

% anchor_rate = 0.4; p = [0.7];lambda1= [91];%MSRC
% anchor_rate = 0.1; p = [0.9];lambda1= [5];%HW1256
% anchor_rate = 0.8; p = [0.6];lambda1= [18];%scene15
% anchor_rate = 1;   p = [0.8];lambda1= [90];%mnist

%% main
IterMax = 300;
anchor_num=fix(anchor_rate*num_N);

filename=['result-' dataname '.txt'];
fid = fopen(filename,'a');
for num1 = 1:length(anchor_rate)
    %------------------------------
    %% anchor graph
    opt1.style = 1;          % 1:das  2:r-samply  4:kmeans
    opt1.IterMax = 50;                      % anchor最大迭代次数
    opt1.toy = 0;
    anchorNum = fix(num_N * anchor_rate);
    [~, B_init] = FastmultiCLR(X, nc, anchorNum(num1), opt1, 10);

    B_init_hat = time2frequency(B_init);
    

    for num2 = 1:length(p)
        for num3 = 1:length(lambda1)
            tic;
           [final_result,label,history,iter,H,H_hat] = main(B_init_hat,Y,nv,nc,anchor_rate(num1),p(num2),lambda1(num3),IterMax);
           for n_result = 1:length(final_result)
                  fprintf(fid, '%f ' ,final_result(n_result));
                  fprintf('%f ' ,final_result(n_result));
           end
           mytime=toc;
           fprintf('\n');
           fprintf('anchor_rate=%f_p=%f_lambda1=%f_iter=%f\n', anchor_rate(num1),p(num2),lambda1(num3),iter);
           fprintf(fid, 'anchor_rate=%f_p=%f_lambda1=%f_iter=%f\n', anchor_rate(num1),p(num2),lambda1(num3),iter);
        end 
    end
end

% --------画图 锚图----------
% B_sum=zeros(num_N,anchorNum);
% for i=1:v
%     B_sum = B_sum + B_init{i};
% end
% figure;
% imagesc(B_sum);
% colorbar;
% colormap(parula);

% --------画图 锚点标签----------
% for i=1:v
%     Q_hat{i} = B_init_hat{i}'*H_hat{i};
% end
% Q=frequency2time(Q_hat);
% Q_sum=zeros(anchorNum,nc);
% for i=1:v
%     Q_sum = Q_sum + Q{i};
% end
% figure;
% imagesc(Q_sum);
% colorbar;
% colormap(parula);

% --------画图H----------
% H_sum = zeros(num_N,nc);
% for i=1:v
%     H_sum = H_sum + H{i};
% end
% figure;
% imagesc(H_sum);
% colorbar;
% colormap(parula);
% 
% exportgraphics(figure(1),'label_msrc.pdf', 'Resolution',600);

%% ================t-SNE可视化==============
% for i=1:v
%    figure(i)
%    T=zscore(X{i});%标准化
%    TT=tsne(T);
%    gscatter(TT(:,1),TT(:,2),label);
%    ax.Units = 'centimeters';%将其设置为normalized可使其随figure的调整而调整
%    ax.OuterPosition(3:4) = [10,8]; %设置绘图区域尺寸(包括标签）
%    set(legend,'Location','Northeast','FontName','Times New Roman','FontSize',10);%字体设置
% end

% % exportgraphics(figure(2),'tsne_hw.pdf', 'Resolution',600);

%========================================

fclose(fid);